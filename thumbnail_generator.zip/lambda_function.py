# Create the lambda_function.py with better error handling
import boto3
import json
import os
import sys
from datetime import datetime
from io import BytesIO

# Debug: Print Python path and available modules
print("Python path:", sys.path)
print("Current directory contents:", os.listdir('.'))

# Import Pillow with better error handling
try:
    from PIL import Image, ImageFile
    # Allow truncated images to load
    ImageFile.LOAD_TRUNCATED_IMAGES = True
    print("✓ Successfully imported Pillow")
except ImportError as e:
    print(f"✗ Failed to import Pillow: {e}")
    # List what's in PIL directory if it exists
    if os.path.exists('PIL'):
        print("Contents of PIL directory:", os.listdir('PIL'))
    raise

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

THUMBNAIL_BUCKET = os.environ.get('THUMBNAIL_BUCKET', 'thumbnails-bucket-0a20035h')
DYNAMODB_TABLE = os.environ.get('DYNAMODB_TABLE', 'ImageMetadata')

def lambda_handler(event, context):
    """
    Process images uploaded to S3 and generate thumbnails
    """
    print("=" * 50)
    print("Lambda function started")
    print(f"Event: {json.dumps(event, indent=2)}")
    print(f"Environment variables:")
    print(f"  THUMBNAIL_BUCKET: {THUMBNAIL_BUCKET}")
    print(f"  DYNAMODB_TABLE: {DYNAMODB_TABLE}")
    print("=" * 50)
    
    try:
        for record in event.get('Records', []):
            # Handle S3 event
            if 's3' in record:
                bucket = record['s3']['bucket']['name']
                key = record['s3']['object']['key']
                
                print(f"\nProcessing image: s3://{bucket}/{key}")
                
                # Skip if already a thumbnail
                if bucket == THUMBNAIL_BUCKET:
                    print("Skipping - file is in thumbnail bucket")
                    continue
                
                # Download the image
                try:
                    response = s3_client.get_object(Bucket=bucket, Key=key)
                    image_data = response['Body'].read()
                    file_size = response['ContentLength']
                    last_modified = response['LastModified'].isoformat()
                    
                    print(f"✓ Downloaded {file_size} bytes")
                    print(f"✓ File last modified: {last_modified}")
                    
                except Exception as e:
                    print(f"✗ Error downloading file: {str(e)}")
                    continue
                
                # Generate thumbnail
                try:
                    thumbnail_bytes = generate_thumbnail(image_data)
                    print(f"✓ Generated thumbnail: {len(thumbnail_bytes)} bytes")
                except Exception as e:
                    print(f"✗ Error generating thumbnail: {str(e)}")
                    continue
                
                # Upload thumbnail to S3
                try:
                    # Preserve folder structure in thumbnails
                    if '/' in key:
                        thumbnail_key = f"thumbnails/{key.rsplit('/', 1)[0]}/{key.rsplit('/', 1)[1].rsplit('.', 1)[0]}.jpg"
                    else:
                        thumbnail_key = f"thumbnails/{key.rsplit('.', 1)[0]}.jpg"
                    
                    s3_client.put_object(
                        Bucket=THUMBNAIL_BUCKET,
                        Key=thumbnail_key,
                        Body=thumbnail_bytes,
                        ContentType='image/jpeg',
                        Metadata={
                            'original-image': key,
                            'processed-by': 'thumbnail-generator'
                        }
                    )
                    print(f"✓ Uploaded thumbnail to: s3://{THUMBNAIL_BUCKET}/{thumbnail_key}")
                    
                except Exception as e:
                    print(f"✗ Error uploading thumbnail: {str(e)}")
                    continue
                
                # Store metadata in DynamoDB
                try:
                    store_metadata(key, file_size, last_modified, thumbnail_key)
                    print(f"✓ Metadata stored in DynamoDB table: {DYNAMODB_TABLE}")
                except Exception as e:
                    print(f"✗ Error storing metadata: {str(e)}")
                    continue
                
                print(f"✓ Successfully processed: {key}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Processing completed successfully',
                'processedCount': len(event.get('Records', []))
            })
        }
        
    except Exception as e:
        print(f"✗ Unexpected error in handler: {str(e)}")
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Internal server error',
                'error': str(e)
            })
        }

def generate_thumbnail(image_bytes, size=(100, 100)):
    """
    Generate a thumbnail from image bytes
    """
    # Open image from bytes
    image = Image.open(BytesIO(image_bytes))
    
    # Convert to RGB if necessary
    if image.mode in ('RGBA', 'LA', 'P'):
        # Create white background for transparent images
        background = Image.new('RGB', image.size, (255, 255, 255))
        if image.mode == 'P':
            image = image.convert('RGBA')
        background.paste(image, mask=image.split()[-1] if image.mode == 'RGBA' else None)
        image = background
    elif image.mode != 'RGB':
        image = image.convert('RGB')
    
    # Create thumbnail (maintains aspect ratio)
    image.thumbnail(size, Image.Resampling.LANCZOS)
    
    # Convert to bytes
    output_buffer = BytesIO()
    image.save(output_buffer, format='JPEG', quality=85, optimize=True)
    output_buffer.seek(0)
    
    return output_buffer.read()

def store_metadata(image_name, image_size, creation_date, thumbnail_key):
    """
    Store image metadata in DynamoDB
    """
    table = dynamodb.Table(DYNAMODB_TABLE)
    
    item = {
        'ImageName': image_name,
        'ImageSize': str(image_size),
        'CreationDate': creation_date,
        'ProcessedDate': datetime.now().isoformat(),
        'ThumbnailKey': thumbnail_key,
        'ThumbnailBucket': THUMBNAIL_BUCKET,
        'Status': 'PROCESSED'
    }
    
    table.put_item(Item=item)
    
    return item

# Test code for local testing
if __name__ == "__main__":
    # Mock event for local testing
    mock_event = {
        "Records": [
            {
                "s3": {
                    "bucket": {
                        "name": "test-bucket"
                    },
                    "object": {
                        "key": "test-image.jpg"
                    }
                }
            }
        ]
    }
    
    # Set environment variables for testing
    os.environ['THUMBNAIL_BUCKET'] = 'thumbnails-bucket-0a20035h'
    os.environ['DYNAMODB_TABLE'] = 'ImageMetadata'
    
    result = lambda_handler(mock_event, None)
    print(f"Test result: {result}")
EOF